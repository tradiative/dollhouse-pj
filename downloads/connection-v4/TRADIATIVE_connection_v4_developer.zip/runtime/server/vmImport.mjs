// server/vmImport.ts
import path3 from "node:path";
import { createHash as createHash2 } from "node:crypto";
import { pathToFileURL } from "node:url";

// server/chatgpt.ts
import { randomBytes, randomUUID, createHash, timingSafeEqual } from "node:crypto";
import { mkdir, readFile, writeFile, rename, chmod, unlink } from "node:fs/promises";
import path from "node:path";
import { createLocalJWKSet, jwtVerify } from "jose";
var AUTH = "https://auth.openai.com";
var RESOURCE = "https://api.openai.com/v1";
var SCOPES = "openid profile email offline_access resource.invoke chatgpt.tokens.use.direct";
var PlanError = class extends Error {
  constructor(state, message) {
    super(message);
    this.state = state;
  }
  state;
};
var secret = () => randomBytes(32).toString("base64url");
function same(a, b) {
  const x = Buffer.from(a), y = Buffer.from(b);
  return x.length === y.length && timingSafeEqual(x, y);
}
var ChatGPTSession = class {
  constructor(directory, http, now = () => Date.now()) {
    this.directory = directory;
    this.http = http;
    this.now = now;
  }
  directory;
  http;
  now;
  pending;
  credential;
  registration;
  hostId = "";
  refreshJob;
  loaded = false;
  transfer;
  csrf = secret();
  models = [];
  lastError = "";
  lastState = "disconnected";
  lastCompleted;
  async save(name, value) {
    await mkdir(this.directory, { recursive: true, mode: 448 });
    await chmod(this.directory, 448);
    const target = path.join(this.directory, name), temp = target + "." + randomUUID() + ".tmp";
    await writeFile(temp, JSON.stringify(value), { mode: 384, flag: "wx" });
    await rename(temp, target);
    await chmod(target, 384);
  }
  async load() {
    if (this.loaded) return;
    const read = async (name) => {
      try {
        return JSON.parse(await readFile(path.join(this.directory, name), "utf8"));
      } catch (e) {
        if (e.code === "ENOENT") return void 0;
        throw new PlanError("failed", "\uC571\uC758 \uBCF4\uD638\uB41C \uC778\uC99D \uAE30\uB85D\uC744 \uC77D\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
      }
    };
    const host = await read("host.json");
    if (host && (typeof host.id !== "string" || !/^urn:uuid:[a-f0-9-]{36}$/.test(host.id))) throw new PlanError("failed", "\uC800\uC7A5\uB41C \uC571 \uD638\uC2A4\uD2B8 \uC2DD\uBCC4\uC790\uAC00 \uC798\uBABB\uB418\uC5C8\uC2B5\uB2C8\uB2E4. \uAE30\uC874 \uC778\uC99D \uAE30\uB85D\uC744 \uC790\uB3D9 \uAD50\uCCB4\uD558\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.");
    this.hostId = typeof host?.id === "string" && /^urn:uuid:[a-f0-9-]{36}$/.test(host.id) ? host.id : "urn:uuid:" + randomUUID();
    if (!host) await this.save("host.json", { id: this.hostId });
    this.registration = await read("registration.json");
    const c = await read("credentials.json");
    if (c && typeof c.accessToken === "string" && typeof c.refreshToken === "string" && typeof c.idToken === "string" && typeof c.subject === "string" && typeof c.clientId === "string" && Array.isArray(c.scopes) && Number.isFinite(c.expiresAt) && c.subject === this.registration?.subject && c.clientId === this.registration?.clientId) this.credential = c;
    this.transfer = await read("transfer-pending.json");
    this.loaded = true;
  }
  status() {
    return {
      loginCompleted: Boolean(this.credential),
      modelAccessVerified: this.models.length > 0,
      actualRequestVerified: Boolean(this.lastCompleted),
      geometryVerified: this.lastCompleted?.validDesign === true,
      transferPending: Boolean(this.transfer),
      account: this.credential ? { email: this.credential.email, registration: this.credential.clientId.slice(-8) } : null,
      models: this.models,
      remainingUsage: null,
      lastState: this.lastState,
      error: this.lastError,
      lastCompleted: this.lastCompleted || null
    };
  }
  async initialize() {
    await this.load();
    return this.status();
  }
  async begin(origin) {
    await this.load();
    if (this.transfer) throw new PlanError("denied", "\uC11C\uBC84 \uC774\uC804\uC744 \uB9C8\uBB34\uB9AC\uD574\uC57C \uD569\uB2C8\uB2E4. PC\uC5D0\uC11C \uAC19\uC740 \uAC31\uC2E0 \uC138\uC158\uC744 \uB2E4\uC2DC \uC0AC\uC6A9\uD558\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.");
    const u = new URL(origin);
    if (u.protocol !== "http:" || u.hostname !== "127.0.0.1" || !u.port) throw new PlanError("unsupported", "\uAC1C\uC778 \uC2E4\uD589 \uB85C\uADF8\uC778\uC740 \uC0AC\uC6A9\uC790 PC\uC758 127.0.0.1 \uD654\uBA74\uC5D0\uC11C\uB9CC \uC2DC\uC791\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4.");
    const pending = { state: secret(), nonce: secret(), verifier: secret(), redirectUri: origin + "/auth/callback", expires: this.now() + 10 * 6e4, registration: this.registration };
    this.pending = pending;
    const params = new URLSearchParams({
      client_id: this.registration?.clientId || "dynamic_agent_client",
      ext_agent_host_id: this.hostId,
      response_type: "code",
      redirect_uri: pending.redirectUri,
      scope: SCOPES,
      resource: RESOURCE,
      state: pending.state,
      nonce: pending.nonce,
      code_challenge_method: "S256",
      code_challenge: createHash("sha256").update(pending.verifier).digest("base64url")
    });
    if (!this.registration) params.set("agent_name_hint", "TRADIATIVE Studio");
    if (this.credential?.idToken) params.set("id_token_hint", this.credential.idToken);
    this.lastError = "";
    return AUTH + "/api/accounts/authorize?" + params;
  }
  async callback(query) {
    const p = this.pending;
    if (!p || p.expires < this.now() || !same(query.get("state") || "", p.state)) throw new PlanError("denied", "\uB9CC\uB8CC\uB418\uC5C8\uAC70\uB098 \uC77C\uCE58\uD558\uC9C0 \uC54A\uB294 \uB85C\uADF8\uC778 \uC694\uCCAD\uC785\uB2C8\uB2E4. \uB2E4\uC2DC \uB85C\uADF8\uC778\uD558\uC138\uC694.");
    this.pending = void 0;
    if (query.has("error")) {
      this.lastState = "denied";
      throw new PlanError("denied", "\uB85C\uADF8\uC778 \uB610\uB294 \uC0AC\uC6A9\uB7C9 \uC5F0\uACB0 \uB3D9\uC758\uAC00 \uC644\uB8CC\uB418\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.");
    }
    const clientId = query.get("client_id") || p.registration?.clientId;
    if (!clientId || clientId === "dynamic_agent_client" || clientId.length > 200 || p.registration && clientId !== p.registration.clientId || !query.get("code")) throw new PlanError("denied", "\uB85C\uADF8\uC778\uC758 \uC571 \uB4F1\uB85D \uC815\uBCF4\uB97C \uD655\uC778\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
    const token = await this.token(new URLSearchParams({ grant_type: "authorization_code", client_id: clientId, code: query.get("code"), code_verifier: p.verifier, redirect_uri: p.redirectUri, resource: RESOURCE }));
    if (typeof token.id_token !== "string") throw new PlanError("denied", "\uC2E0\uC6D0\uC744 \uAC80\uC99D\uD560 ID \uD1A0\uD070\uC774 \uC5C6\uC2B5\uB2C8\uB2E4.");
    const metadata = await this.metadata();
    const jwksResponse = await this.http(metadata.jwks_uri, { signal: AbortSignal.timeout(15e3) });
    if (!jwksResponse.ok) throw new PlanError("failed", "\uACF5\uC2DD \uB85C\uADF8\uC778 \uC11C\uBA85 \uC815\uBCF4\uB97C \uC77D\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
    const jwks = await jwksResponse.json();
    let claims;
    try {
      claims = (await jwtVerify(token.id_token, createLocalJWKSet(jwks), { issuer: AUTH, audience: clientId, algorithms: ["RS256"], requiredClaims: ["sub", "exp", "iat", "nonce"], currentDate: new Date(this.now()) })).payload;
    } catch {
      throw new PlanError("denied", "\uB85C\uADF8\uC778 \uD1A0\uD070\uC758 \uC11C\uBA85\xB7\uB300\uC0C1\xB7\uC720\uD6A8\uAE30\uAC04 \uAC80\uC99D\uC5D0 \uC2E4\uD328\uD588\uC2B5\uB2C8\uB2E4.");
    }
    if (typeof claims.sub !== "string" || claims.nonce !== p.nonce || p.registration && p.registration.subject !== claims.sub) throw new PlanError("denied", "\uB85C\uADF8\uC778 \uC2E0\uC6D0 \uB610\uB294 \uC694\uCCAD \uC2DD\uBCC4\uC790\uAC00 \uC77C\uCE58\uD558\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.");
    const registration = { clientId, subject: claims.sub, issuer: AUTH, email: typeof claims.email === "string" ? claims.email : "ChatGPT \uACC4\uC815" };
    const next = this.credentials(token, registration);
    await this.save("credentials.json", next);
    await this.save("registration.json", registration);
    this.registration = registration;
    this.credential = next;
    this.models = [];
    this.lastCompleted = void 0;
    this.lastState = "authenticated";
    this.lastError = "";
    return this.status();
  }
  credentials(token, registration, previous) {
    if (typeof token.access_token !== "string" || token.token_type !== "Bearer" || typeof token.expires_in !== "number" || token.expires_in <= 0 || token.expires_in > 86400) throw new PlanError("denied", "\uACF5\uC2DD \uB85C\uADF8\uC778 \uC751\uB2F5 \uD615\uC2DD\uC774 \uB9DE\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.");
    const scopes = typeof token.scope === "string" ? token.scope.split(/\s+/) : previous?.scopes || [];
    const refreshToken = typeof token.refresh_token === "string" ? token.refresh_token : previous?.refreshToken;
    if (!refreshToken) throw new PlanError("denied", "\uAC31\uC2E0 \uAC00\uB2A5\uD55C \uB85C\uADF8\uC778 \uAD8C\uD55C\uC774 \uC5C6\uC2B5\uB2C8\uB2E4.");
    return { ...registration, accessToken: token.access_token, refreshToken, idToken: typeof token.id_token === "string" ? token.id_token : previous.idToken, scopes, expiresAt: this.now() + token.expires_in * 1e3 };
  }
  async token(form) {
    const r = await this.http(AUTH + "/api/accounts/oauth/token", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: form.toString(), signal: AbortSignal.timeout(2e4) });
    if (!r.ok) throw new PlanError(r.status === 429 ? "limited" : "denied", "\uB85C\uADF8\uC778 \uAD50\uD658\xB7\uAC31\uC2E0\uC774 \uC644\uB8CC\uB418\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4. \uBCC4\uB3C4 API\uB85C \uC804\uD658\uD558\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.");
    return await r.json();
  }
  async metadata() {
    const r = await this.http(AUTH + "/.well-known/openid-configuration", { signal: AbortSignal.timeout(15e3) });
    if (!r.ok) throw new PlanError("failed", "\uACF5\uC2DD \uC778\uC99D \uBA54\uD0C0\uB370\uC774\uD130\uB97C \uC77D\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
    const d = await r.json();
    if (d.issuer !== AUTH || !d.jwks_uri || new URL(d.jwks_uri).origin !== AUTH || d.revocation_endpoint && new URL(d.revocation_endpoint).origin !== AUTH) throw new PlanError("failed", "\uACF5\uC2DD \uC778\uC99D \uBA54\uD0C0\uB370\uC774\uD130\uC758 \uCD9C\uCC98\uAC00 \uB9DE\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.");
    return d;
  }
  async accessToken() {
    await this.load();
    if (this.transfer) throw new PlanError("denied", "\uC774 \uB85C\uADF8\uC778\uC740 \uC11C\uBC84\uB85C \uC774\uC804 \uC911\uC785\uB2C8\uB2E4. \uAC31\uC2E0\uC740 \uB300\uC0C1 \uC11C\uBC84\uB9CC \uB2F4\uB2F9\uD569\uB2C8\uB2E4.");
    if (!this.credential) throw new PlanError("disconnected", "\uBA3C\uC800 \uACF5\uC2DD ChatGPT \uB85C\uADF8\uC778\uC744 \uC644\uB8CC\uD558\uC138\uC694.");
    if (!this.credential.scopes.includes("chatgpt.tokens.use.direct") || !this.credential.scopes.includes("resource.invoke")) throw new PlanError("denied", "\uB85C\uADF8\uC778\uB9CC \uC644\uB8CC\uB410\uC73C\uBA70 ChatGPT \uC0AC\uC6A9\uB7C9 \uD638\uCD9C \uAD8C\uD55C\uC774 \uC5C6\uC2B5\uB2C8\uB2E4. \uC5F0\uACB0 \uB3D9\uC758\uB97C \uB2E4\uC2DC \uD655\uC778\uD558\uC138\uC694.");
    if (this.credential.expiresAt > this.now() + 6e4) return this.credential.accessToken;
    if (!this.refreshJob) this.refreshJob = (async () => {
      const current = this.credential;
      const token = await this.token(new URLSearchParams({ grant_type: "refresh_token", client_id: current.clientId, refresh_token: current.refreshToken, resource: RESOURCE }));
      const next = this.credentials(token, current, current);
      await this.save("credentials.json", next);
      this.credential = next;
      return next.accessToken;
    })().finally(() => {
      this.refreshJob = void 0;
    });
    return this.refreshJob;
  }
  async listModels() {
    const token = await this.accessToken();
    const r = await this.http(RESOURCE + "/models", { headers: { Authorization: "Bearer " + token }, signal: AbortSignal.timeout(2e4) });
    if (!r.ok) throw new PlanError(r.status === 429 ? "limited" : "denied", "\uC774 \uACC4\uC815\uC758 \uBAA8\uB378 \uC0AC\uC6A9 \uAD8C\uD55C\uC744 \uD655\uC778\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
    const data = await r.json();
    if (!Array.isArray(data.models)) throw new PlanError("failed", "\uACC4\uC815 \uBAA8\uB378 \uBAA9\uB85D\uC758 \uD615\uC2DD\uC774 \uB9DE\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.");
    this.models = data.models.filter((m) => m.visibility === "list" && typeof m.slug === "string" && typeof m.display_name === "string").slice(0, 100).map((m) => ({ slug: m.slug, display_name: m.display_name }));
    if (!this.models.length) throw new PlanError("denied", "\uC774 \uACC4\uC815\uC5D0\uC11C \uC120\uD0DD \uAC00\uB2A5\uD55C \uBAA8\uB378\uC774 \uC5C6\uC2B5\uB2C8\uB2E4.");
    this.lastState = "model-access";
    this.lastError = "";
    return this.models;
  }
  async infer(model, input, instructions, signal) {
    if (!this.models.some((m) => m.slug === model)) throw new PlanError("denied", "\uD604\uC7AC \uACC4\uC815\uC5D0\uC11C \uD655\uC778\uD55C \uBAA8\uB378\uC744 \uC120\uD0DD\uD558\uC138\uC694.");
    const token = await this.accessToken();
    const r = await this.http(RESOURCE + "/responses", { method: "POST", headers: { Authorization: "Bearer " + token, "Content-Type": "application/json" }, body: JSON.stringify({ model, input, instructions, store: false, stream: true }), signal });
    if (!r.ok) throw new PlanError(r.status === 429 ? "limited" : r.status === 401 || r.status === 403 ? "denied" : "failed", "ChatGPT\uAC00 \uC694\uCCAD\uC744 \uC644\uB8CC\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. \uBCC4\uB3C4 API\uB85C \uC804\uD658\uD558\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.");
    return readPlanStream(r, signal);
  }
  async logout() {
    await this.load();
    if (this.transfer) throw new PlanError("denied", "\uC774\uC804 \uC911\uC778 \uAC31\uC2E0 \uC138\uC158\uC740 PC\uC5D0\uC11C \uD574\uC81C\uD558\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4. \uB300\uC0C1 \uC11C\uBC84\uC758 \uC5F0\uACB0 \uC0C1\uD0DC\uB97C \uBA3C\uC800 \uD655\uC778\uD558\uC138\uC694.");
    this.pending = void 0;
    this.models = [];
    this.lastCompleted = void 0;
    let remoteRevoked = false;
    if (this.credential) {
      try {
        const metadata = await this.metadata();
        if (metadata.revocation_endpoint) {
          const r = await this.http(metadata.revocation_endpoint, { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({ token: this.credential.refreshToken, token_type_hint: "refresh_token", client_id: this.credential.clientId }).toString(), signal: AbortSignal.timeout(1e4) });
          remoteRevoked = r.status === 200;
        }
      } catch {
      }
    }
    this.credential = void 0;
    await unlink(path.join(this.directory, "credentials.json")).catch((e) => {
      if (e.code !== "ENOENT") throw e;
    });
    this.lastState = "disconnected";
    return { remoteRevoked, message: remoteRevoked ? "\uC571 \uB85C\uADF8\uC778\uACFC \uAC31\uC2E0 \uC138\uC158\uC744 \uD574\uC81C\uD588\uC2B5\uB2C8\uB2E4." : "\uC571\uC5D0\uC11C \uB85C\uADF8\uC544\uC6C3\uD588\uC2B5\uB2C8\uB2E4. \uC6D0\uACA9 \uC138\uC158 \uD574\uC81C\uB294 \uD655\uC778\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. ChatGPT \uC124\uC815\uC5D0\uC11C \uC774 \uC571\uC758 \uC5F0\uACB0\uC744 \uD574\uC81C\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4." };
  }
  /** Only the credentials issued by THIS app's validated OAuth flow. Never reads other apps. */
  async prepareTransfer() {
    await this.load();
    if (this.transfer) return this.transfer;
    await this.accessToken();
    this.transfer = { format: "tradiative.app-owned-siwc.v1", id: randomUUID(), createdAt: this.now(), credential: { ...this.credential } };
    await this.save("transfer-pending.json", this.transfer);
    return this.transfer;
  }
  async finishTransfer(id) {
    await this.load();
    if (!this.transfer || this.transfer.id !== id) throw new PlanError("denied", "\uC11C\uBC84 \uC774\uC804 \uD655\uC778\uC774 \uC77C\uCE58\uD558\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.");
    await unlink(path.join(this.directory, "credentials.json")).catch((e) => {
      if (e.code !== "ENOENT") throw e;
    });
    await unlink(path.join(this.directory, "transfer-pending.json"));
    this.credential = void 0;
    this.transfer = void 0;
    this.models = [];
    this.lastCompleted = void 0;
    this.lastState = "transferred";
  }
  /** Called only by the offline SSH importer, never by a public HTTP endpoint. */
  async importTransfer(value) {
    await this.load();
    const c = value?.credential;
    if (value?.format !== "tradiative.app-owned-siwc.v1" || !/^[a-f0-9-]{36}$/.test(value.id || "") || !Number.isFinite(value.createdAt) || this.now() - value.createdAt > 6e5 || value.createdAt > this.now() + 3e4 || !c || c.issuer !== AUTH || typeof c.clientId !== "string" || c.clientId === "dynamic_agent_client" || typeof c.subject !== "string" || typeof c.accessToken !== "string" || typeof c.refreshToken !== "string" || !Array.isArray(c.scopes) || !c.scopes.includes("resource.invoke") || !c.scopes.includes("chatgpt.tokens.use.direct") || !Number.isFinite(c.expiresAt) || c.expiresAt <= this.now()) throw new PlanError("denied", "\uC774 \uC571\uC758 \uC0C8 \uB85C\uADF8\uC778\xB7\uC0AC\uC6A9\uB7C9 \uB3D9\uC758\uB85C \uBC1C\uAE09\uB41C \uC720\uD6A8\uD55C \uC774\uC804 \uAE30\uB85D\uC774 \uC544\uB2D9\uB2C8\uB2E4.");
    if (this.registration && (c.subject !== this.registration.subject || c.clientId !== this.registration.clientId)) throw new PlanError("denied", "\uAE30\uC874 \uC11C\uBC84\uC758 \uACC4\uC815\xB7\uC6CC\uD06C\uC2A4\uD398\uC774\uC2A4 \uB4F1\uB85D\uACFC \uB2E4\uB978 \uB85C\uADF8\uC778\uC740 \uAC00\uC838\uC624\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.");
    const metadata = await this.metadata(), r = await this.http(metadata.jwks_uri, { signal: AbortSignal.timeout(15e3) });
    if (!r.ok) throw new PlanError("failed", "\uC11C\uBC84\uC5D0\uC11C \uB85C\uADF8\uC778 \uC11C\uBA85\uC744 \uD655\uC778\uD558\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4.");
    try {
      const claims = (await jwtVerify(c.idToken, createLocalJWKSet(await r.json()), { issuer: AUTH, audience: c.clientId, algorithms: ["RS256"], requiredClaims: ["sub", "exp", "iat"], currentDate: new Date(this.now()) })).payload;
      if (claims.sub !== c.subject) throw new Error("subject");
    } catch {
      throw new PlanError("denied", "\uC774\uC804\uD558\uB294 \uB85C\uADF8\uC778 \uC2E0\uC6D0\uC758 \uC11C\uBA85\xB7\uB300\uC0C1\xB7\uC720\uD6A8\uAE30\uAC04\uC774 \uB9DE\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.");
    }
    const registration = { clientId: c.clientId, subject: c.subject, issuer: AUTH, email: c.email };
    await this.save("credentials.json", c);
    await this.save("registration.json", registration);
    this.credential = c;
    this.registration = registration;
    this.models = [];
    this.lastCompleted = void 0;
    this.lastState = "authenticated";
  }
};
async function readPlanStream(response, signal) {
  if (!response.body) throw new PlanError("failed", "AI \uC751\uB2F5 \uC2A4\uD2B8\uB9BC\uC774 \uC5C6\uC2B5\uB2C8\uB2E4.");
  const reader = response.body.getReader(), decoder = new TextDecoder();
  const abortRead = () => {
    void reader.cancel().catch(() => {
    });
  };
  signal?.addEventListener("abort", abortRead, { once: true });
  let buffer = "", total = 0, completed;
  const event = (block) => {
    const data = block.split("\n").filter((l) => l.startsWith("data:")).map((l) => l.slice(5).trimStart()).join("\n");
    if (!data || data === "[DONE]") return;
    let e;
    try {
      e = JSON.parse(data);
    } catch {
      throw new PlanError("failed", "AI \uC2A4\uD2B8\uB9BC \uD615\uC2DD\uC774 \uB9DE\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.");
    }
    if (["response.failed", "response.incomplete", "error"].includes(e.type || "")) {
      const error = e.response?.error;
      const code = error?.code || e.error?.code || e.code || "";
      throw new PlanError(/usage_limit|usage_unavailable|rate_limit/.test(code) ? "limited" : "failed", "AI\uAC00 \uC751\uB2F5\uC744 \uB05D\uB0B4\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. \uC774\uC804 \uD615\uC0C1\uC744 \uBCF4\uC874\uD569\uB2C8\uB2E4.");
    }
    if (e.type === "response.completed") {
      if (e.response?.status !== "completed" || typeof e.response.id !== "string" || !e.response.id) throw new PlanError("failed", "AI \uCD5C\uC885 \uC644\uB8CC \uC0C1\uD0DC\xB7\uC694\uCCAD \uC2DD\uBCC4\uAC12\uC774 \uB9DE\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.");
      completed = e.response;
    }
  };
  try {
    while (true) {
      if (signal?.aborted) throw new PlanError("cancelled", "AI \uC791\uC5C5\uC744 \uCDE8\uC18C\uD588\uC2B5\uB2C8\uB2E4.");
      const { value, done } = await reader.read();
      if (signal?.aborted) throw new PlanError("cancelled", "AI \uC791\uC5C5\uC744 \uCDE8\uC18C\uD588\uC2B5\uB2C8\uB2E4.");
      if (done) break;
      total += value.length;
      if (total > 6e6) throw new PlanError("limited", "AI \uC751\uB2F5 \uD06C\uAE30 \uD55C\uB3C4\uB97C \uB118\uC5C8\uC2B5\uB2C8\uB2E4.");
      buffer = (buffer + decoder.decode(value, { stream: true })).replace(/\r\n/g, "\n");
      let end;
      while ((end = buffer.indexOf("\n\n")) >= 0) {
        event(buffer.slice(0, end));
        buffer = buffer.slice(end + 2);
      }
      if (completed) {
        await reader.cancel();
        return completed;
      }
    }
    buffer += decoder.decode();
    if (buffer.trim()) event(buffer);
    if (!completed) throw new PlanError("failed", "\uCD5C\uC885 response.completed \uC5C6\uC774 AI \uC751\uB2F5\uC774 \uC911\uB2E8\uB410\uC2B5\uB2C8\uB2E4.");
    return completed;
  } finally {
    signal?.removeEventListener("abort", abortRead);
    await reader.cancel().catch(() => {
    });
    reader.releaseLock();
  }
}

// server/privateFiles.ts
import { mkdir as mkdir2, chmod as chmod2, open, readFile as readFile2, rename as rename2, unlink as unlink2, lstat } from "node:fs/promises";
import path2 from "node:path";
import { randomUUID as randomUUID2 } from "node:crypto";
async function privateWrite(directory, name, value) {
  await mkdir2(directory, { recursive: true, mode: 448 });
  await chmod2(directory, 448);
  const target = path2.join(directory, name), temp = target + "." + randomUUID2() + ".tmp";
  const f = await open(temp, "wx", 384);
  try {
    await f.writeFile(JSON.stringify(value));
    await f.sync();
  } finally {
    await f.close();
  }
  await rename2(temp, target);
}
async function privateRead(directory, name) {
  const file = path2.join(directory, name), info = await lstat(file);
  if (!info.isFile() || info.isSymbolicLink() || process.platform !== "win32" && (info.mode & 63) !== 0 || info.size > 2e5) throw new Error("\uBCF4\uD638\uB41C \uC571 \uAE30\uB85D\uC758 \uAD8C\uD55C \uB610\uB294 \uD615\uC2DD\uC774 \uB9DE\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.");
  return JSON.parse(await readFile2(file, "utf8"));
}
async function lockAuthDirectory(directory) {
  await mkdir2(directory, { recursive: true, mode: 448 });
  await chmod2(directory, 448);
  const file = path2.join(directory, "runtime.lock"), f = await open(file, "wx", 384);
  await f.writeFile(String(process.pid));
  await f.close();
  return async () => {
    await unlink2(file);
  };
}

// server/planTransport.ts
import { EnvHttpProxyAgent, fetch as proxyFetch } from "undici";
var dispatcher = new EnvHttpProxyAgent();
var planHttp = async (url, init) => await proxyFetch(url, { ...init, dispatcher });

// server/vmImport.ts
async function importVm(directory, packet, http = planHttp) {
  const unlock = await lockAuthDirectory(directory);
  try {
    const hash = createHash2("sha256").update(JSON.stringify(packet)).digest("hex");
    const receipt = await privateRead(directory, "import-receipt.json").catch((e) => {
      if (e.code === "ENOENT") return null;
      throw e;
    });
    if (receipt?.id === packet.transfer?.id) {
      if (receipt.hash !== hash) throw new Error("\uC774\uC804 \uAE30\uB85D\uC774 \uBC14\uB00C\uC5C8\uC2B5\uB2C8\uB2E4.");
      return { id: receipt.id, imported: true };
    }
    const owner = packet.owner, c = packet.transfer?.credential;
    if (!owner || owner.version !== 1 || !/^[a-f0-9]{64}$/.test(owner.salt) || !/^[a-f0-9]{128}$/.test(owner.hash) || owner.subject !== c?.subject || owner.clientId !== c?.clientId) throw new Error("\uC791\uC5C5\uC2E4 \uC18C\uC720\uC790 \uC815\uBCF4\uAC00 \uB9DE\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4.");
    const old = await privateRead(directory, "owner.json").catch((e) => {
      if (e.code === "ENOENT") return null;
      throw e;
    });
    if (old && (old.subject !== owner.subject || old.clientId !== owner.clientId)) throw new Error("\uC774 \uC11C\uBC84\uB294 \uB2E4\uB978 \uACC4\uC815\uC758 \uC791\uC5C5\uC2E4\uC785\uB2C8\uB2E4.");
    const session = new ChatGPTSession(directory, http);
    await session.importTransfer(packet.transfer);
    if (!old) await privateWrite(directory, "owner.json", owner);
    await privateWrite(directory, "import-receipt.json", { id: packet.transfer.id, hash });
    return { id: packet.transfer.id, imported: true };
  } finally {
    await unlock();
  }
}
if (process.argv[1] && import.meta.url === pathToFileURL(path3.resolve(process.argv[1])).href) {
  const directory = process.env.TRADIATIVE_AUTH_DIR;
  try {
    if (!directory || !path3.isAbsolute(directory)) throw new Error("\uBCF4\uD638\uB41C \uC11C\uBC84 \uC800\uC7A5 \uC704\uCE58\uAC00 \uD544\uC694\uD569\uB2C8\uB2E4.");
    let input = "";
    for await (const data of process.stdin) {
      input += data.toString();
      if (input.length > 2e5) throw new Error("\uC774\uC804 \uAE30\uB85D\uC774 \uB108\uBB34 \uD07D\uB2C8\uB2E4.");
    }
    const result = await importVm(directory, JSON.parse(input));
    process.stdout.write(JSON.stringify(result));
  } catch {
    process.stderr.write("TRADIATIVE \uC11C\uBC84 \uC774\uC804 \uC2E4\uD328: \uC2E4\uD589\uBD80 \uC911\uC9C0\xB7\uBCF4\uD638\uB41C \uC800\uC7A5 \uC704\uCE58\xB7\uACC4\uC815\xB7\uACF5\uC2DD \uC11C\uBA85\uC744 \uD655\uC778\uD558\uC138\uC694. \uBE44\uBC00 \uAC12\uC740 \uCD9C\uB825\uD558\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4.\n");
    process.exitCode = 1;
  }
}
export {
  importVm
};
